// Copyright © 2015, skdltmxn
// Licensed under the MIT License <LICENSE.md>
// Master include file for RPC applications.
pub type I_RPC_HANDLE = *mut ::c_void;
pub type RPC_STATUS = ::c_long;
