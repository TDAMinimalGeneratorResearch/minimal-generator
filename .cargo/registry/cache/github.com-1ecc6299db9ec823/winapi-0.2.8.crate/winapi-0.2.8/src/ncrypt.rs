// Copyright © 2015, skdltmxn
// Licensed under the MIT License <LICENSE.md>
//! Cryptographic API Prototypes and Definitions
//191
pub type NCRYPT_HANDLE = ::ULONG_PTR;
pub type NCRYPT_PROV_HANDLE = ::ULONG_PTR;
pub type NCRYPT_KEY_HANDLE = ::ULONG_PTR;
pub type NCRYPT_HASH_HANDLE = ::ULONG_PTR;
pub type NCRYPT_SECRET_HANDLE = ::ULONG_PTR;
