// Copyright © 2015, Peter Atashian
// Licensed under the MIT License <LICENSE.md>
pub type IPropertyDescriptionList = ::IUnknown; // TODO
pub type IPropertyStore = ::IUnknown; // TODO
