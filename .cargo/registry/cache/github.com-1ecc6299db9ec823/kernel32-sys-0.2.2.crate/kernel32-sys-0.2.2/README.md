# kernel32 #
Contains function definitions for the Windows API library kernel32. See winapi for types and constants.

```toml
[dependencies]
kernel32-sys = "0.2.1"
```

```rust
extern crate kernel32;
```

[Documentation](https://retep998.github.io/doc/kernel32/)
