
rawpointer
==========

Please read the `API documentation here`__

__ https://docs.rs/rawpointer/

|build_status|_ |crates|_

.. |build_status| image:: https://travis-ci.org/bluss/rawpointer.svg?branch=master
.. _build_status: https://travis-ci.org/bluss/rawpointer

.. |crates| image:: http://meritbadge.herokuapp.com/rawpointer
.. _crates: https://crates.io/crates/rawpointer


Recent Changes
--------------

- 0.2.0

  - Add support for NonNull<T>
  - Added more documentation and an example
  - Now requires Rust 1.26 or later

- 0.1.0

  - Initial release
