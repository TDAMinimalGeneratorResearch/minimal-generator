//! Standalone documentation pages.

pub mod ndarray_for_numpy_users;
