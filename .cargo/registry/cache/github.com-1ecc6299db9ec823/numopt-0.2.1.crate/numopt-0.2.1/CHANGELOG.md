Version 0.1.0
-------------
* Problem abstractions (Minlp, Milp, Nlp, Lp)
* Solver interfaces (Ipopt, Cbc, Clp)

Version 0.2.1
-------------
* Stopped using traits for problem relations.
* Optimization models.
* Scalar expressions and variables.
* Functions: add, subtract, divide, multiply, negate, cosine, sine.
* Automatic differentiation.