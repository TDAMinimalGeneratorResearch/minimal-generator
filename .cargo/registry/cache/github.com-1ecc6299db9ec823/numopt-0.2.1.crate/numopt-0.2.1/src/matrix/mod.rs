//! Sparse matrix data structures and associated tools.

pub mod coo;
pub mod csr;
pub mod item;