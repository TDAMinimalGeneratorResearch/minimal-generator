# gurobi-sys

Rust FFI declaration for Gurobi C API.

