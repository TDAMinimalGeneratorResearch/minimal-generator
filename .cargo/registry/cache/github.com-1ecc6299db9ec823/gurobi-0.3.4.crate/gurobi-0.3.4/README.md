# rust-gurobi

[![](http://meritbadge.herokuapp.com/gurobi)](https://crates.io/crates/gurobi)

An unofficial Rust API for Gurobi optimizer.

* Documentation - [master](https://ys-nuem.github.io/rust-gurobi/master/gurobi/index.html) / [0.3 (latest)](https://ys-nuem.github.io/rust-gurobi/v0.3.1/gurobi/index.html)

## Notices

* This wrapper library is not officially supported by Gurobi.
* Too many works have not finished yet.


## License

Copyright (c) 2016, Yusuke Sasaki

This software is released under the MIT license, see [LICENSE](LICENSE).
